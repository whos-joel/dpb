import "./../styles/site.less";
import {onload} from "./validation";

window.onload = onload;

